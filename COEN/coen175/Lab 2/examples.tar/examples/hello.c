/* hello.c */

int printf();

int main(void)
{
    printf("Hello, world%c", '\n');
}
